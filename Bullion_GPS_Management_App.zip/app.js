const KEY="bullion_farms_v1", SESSION="bullion_session_v1";
const users=[
 {username:"manager",password:"Bullion123",role:"manager",name:"Regional Manager"},
 ...Array.from({length:6},(_,i)=>({username:`officer${i+1}`,password:"Officer123",role:"officer",name:`Field Officer ${i+1}`}))
];
let current=null, gps=null;

const $=id=>document.getElementById(id);
const load=()=>JSON.parse(localStorage.getItem(KEY)||"[]");
const save=data=>localStorage.setItem(KEY,JSON.stringify(data));
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const fmt=n=>Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2});
const now=()=>new Date().toISOString();

function setOnline(){
 const online=navigator.onLine;
 $("onlineBadge").textContent=online?"Online":"Offline";
 $("onlineBadge").className="badge "+(online?"online":"offline");
}
window.addEventListener("online",()=>{setOnline(); trySync();});
window.addEventListener("offline",setOnline);

function login(user){current=user;sessionStorage.setItem(SESSION,JSON.stringify(user));$("loginScreen").hidden=true;$("app").hidden=false;renderRole();setOnline();}
function logout(){sessionStorage.removeItem(SESSION);location.reload();}
function renderRole(){
 $("managerView").hidden=current.role!=="manager"; $("officerView").hidden=current.role!=="officer";
 if(current.role==="manager") renderManager(); else renderOfficer();
}
$("loginForm").addEventListener("submit",e=>{
 e.preventDefault(); const u=$("username").value.trim(),p=$("password").value;
 const user=users.find(x=>x.username===u&&x.password===p);
 if(!user){$("loginError").textContent="Invalid username or password.";return}
 $("loginError").textContent=""; login(user);
});
$("logoutBtn").onclick=logout;

function getStats(rows){
 return {farmers:rows.length,gps:rows.filter(x=>x.latitude!=null).length,ha:rows.reduce((a,x)=>a+Number(x.areaHa||0),0),kg:rows.reduce((a,x)=>a+Number(x.estimatedKg||0),0),pending:rows.filter(x=>!x.synced).length};
}
function renderManager(){
 const rows=load(),s=getStats(rows); $("managerGreeting").textContent=`Welcome, ${current.name}`;
 $("mFarmers").textContent=fmt(s.farmers);$("mGps").textContent=fmt(s.gps);$("mHa").textContent=fmt(s.ha);$("mKg").textContent=fmt(s.kg);$("mPending").textContent=fmt(s.pending);
 const target=rows.reduce((a,x)=>a+Number(x.targetKg||0),0)||0;
 $("mAchievement").textContent=target?`${Math.round(s.kg/target*100)}%`:"—";
 const officers=users.filter(u=>u.role==="officer");
 $("officerTable").innerHTML=`<div class="table-wrap"><table><thead><tr><th>Officer</th><th>Farmers</th><th>Ha</th><th>Kg</th></tr></thead><tbody>`+
 officers.map(u=>{const r=rows.filter(x=>x.officer===u.username),z=getStats(r);return `<tr><td>${esc(u.name)}</td><td>${z.farmers}</td><td>${fmt(z.ha)}</td><td>${fmt(z.kg)}</td></tr>`}).join("")+`</tbody></table></div>`;
 const recent=[...rows].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,8);
 $("recentTable").innerHTML=recent.length?`<div class="table-wrap"><table><thead><tr><th>Farmer</th><th>Officer</th><th>District</th><th>Date</th></tr></thead><tbody>${recent.map(x=>`<tr><td>${esc(x.farmerName)}</td><td>${esc(x.officer)}</td><td>${esc(x.district)}</td><td>${new Date(x.createdAt).toLocaleDateString()}</td></tr>`).join("")}</tbody></table></div>`:"<p class='muted'>No registrations yet.</p>";
 $("farmTable").innerHTML=rows.length?rows.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(x=>`<tr><td>${new Date(x.createdAt).toLocaleDateString()}</td><td>${esc(x.farmerName)}</td><td>${esc(x.officer)}</td><td>${esc(x.district)}</td><td>${fmt(x.areaHa)}</td><td>${x.latitude!=null?`${Number(x.latitude).toFixed(5)}, ${Number(x.longitude).toFixed(5)}`:"—"}</td><td class="status ${x.synced?"ok":"pending"}">${x.synced?"Synced":"Pending"}</td></tr>`).join(""):"<tr><td colspan='7' class='muted'>No farms registered.</td></tr>";
}
function renderOfficer(){
 const rows=load().filter(x=>x.officer===current.username),s=getStats(rows);
 $("officerGreeting").textContent=`${current.name} • ${navigator.onLine?"Online":"Offline"}`;
 $("oFarmers").textContent=fmt(s.farmers);$("oGps").textContent=fmt(s.gps);$("oHa").textContent=fmt(s.ha);$("oPending").textContent=fmt(s.pending);
 $("myFarmTable").innerHTML=rows.length?rows.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(x=>`<tr><td>${new Date(x.createdAt).toLocaleDateString()}</td><td>${esc(x.farmerName)}</td><td>${esc(x.district)}</td><td>${fmt(x.areaHa)}</td><td>${x.latitude!=null?`${Number(x.latitude).toFixed(5)}, ${Number(x.longitude).toFixed(5)}`:"—"}</td><td class="status ${x.synced?"ok":"pending"}">${x.synced?"Synced":"Pending"}</td></tr>`).join(""):"<tr><td colspan='6' class='muted'>No farms registered yet.</td></tr>";
}
function captureGPS(){
 if(!window.isSecureContext){$("gpsStatus").textContent="GPS requires HTTPS. Open the app from an HTTPS address.";return}
 if(!navigator.geolocation){$("gpsStatus").textContent="Geolocation is not supported on this device/browser.";return}
 $("gpsStatus").textContent="Requesting location permission…";
 navigator.geolocation.getCurrentPosition(pos=>{
   gps={latitude:pos.coords.latitude,longitude:pos.coords.longitude,accuracy:pos.coords.accuracy};
   $("gpsStatus").textContent=`Captured • accuracy ±${Math.round(gps.accuracy)} m`;
   $("gpsDetails").textContent=`Latitude ${gps.latitude.toFixed(6)} • Longitude ${gps.longitude.toFixed(6)} • Accuracy ±${Math.round(gps.accuracy)} m`;
 },err=>{
   const msg={1:"Location permission was denied. Enable Location permission for Chrome.",2:"Location unavailable. Turn on device Location/GPS and try again.",3:"Location request timed out. Move outdoors and try again."}[err.code]||err.message;
   $("gpsStatus").textContent=msg;
 },{enableHighAccuracy:true,timeout:20000,maximumAge:0});
}
$("gpsBtn").onclick=captureGPS;

$("farmForm").addEventListener("submit",e=>{
 e.preventDefault();
 if(!gps){$("formMessage").textContent="Please capture GPS coordinates before saving.";return}
 const row={
   id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),
   createdAt:now(),officer:current.username,
   farmerName:$("farmerName").value.trim(),phone:$("phone").value.trim(),district:$("district").value.trim(),
   ward:$("ward").value.trim(),village:$("village").value.trim(),farmId:$("farmId").value.trim(),
   areaHa:Number($("areaHa").value),estimatedKg:Number($("estimatedKg").value||0),
   variety:$("variety").value.trim(),plantingDate:$("plantingDate").value,notes:$("notes").value.trim(),
   ...gps,synced:false
 };
 const rows=load();rows.push(row);save(rows);
 $("formMessage").textContent="Farm saved on this device. It will remain available offline and can be synchronized when connectivity returns.";
 e.target.reset();gps=null;$("gpsStatus").textContent="Not captured";$("gpsDetails").textContent="";
 renderOfficer();trySync();
});
$("clearFormBtn").onclick=()=>{$("farmForm").reset();gps=null;$("gpsStatus").textContent="Not captured";$("gpsDetails").textContent="";$("formMessage").textContent=""};
$("syncBtn").onclick=trySync;

function trySync(){
 if(!current||!navigator.onLine)return;
 // Demo sync: marks locally stored records as synchronized.
 // Replace this function with a secure API call when the Bullion server is connected.
 const rows=load().map(x=>x.officer===current.username?{...x,synced:true,syncedAt:now()}:x);save(rows);renderOfficer();
}
$("exportBtn").onclick=()=>{
 const rows=load(); if(!rows.length){alert("No records to export.");return}
 const cols=["createdAt","officer","farmerName","phone","district","ward","village","farmId","areaHa","estimatedKg","variety","plantingDate","latitude","longitude","accuracy","notes","synced"];
 const csv=[cols.join(","),...rows.map(r=>cols.map(c=>`"${String(r[c]??"").replaceAll('"','""')}"`).join(","))].join("\n");
 const blob=new Blob([csv],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");
 a.href=url;a.download=`bullion-farms-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(url);
};

const existing=sessionStorage.getItem(SESSION);
if(existing){try{current=JSON.parse(existing);$("loginScreen").hidden=true;$("app").hidden=false;renderRole()}catch{}}
setOnline();
if("serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("sw.js").catch(console.warn);
