# Bullion GPS Management App

## Included
- Manager dashboard
- Six field-officer demo accounts
- Offline farm registration using local browser storage
- GPS capture with accuracy
- Online/offline indicator
- Synchronisation-ready workflow
- CSV export
- Installable PWA shell

## Demo logins
Manager: `manager` / `Bullion123`
Officer 1–6: `officer1` ... `officer6` / `Officer123`

## Important
This is a working offline prototype. The "sync" button currently marks local records as synchronized; it does not transmit data to a remote Bullion server.

For real multi-device management, connect `trySync()` in `app.js` to a secure HTTPS backend/API and replace demo passwords with server-side authentication.

GPS requires HTTPS in production. Android Chrome must have device Location enabled and site Location permission allowed.

## Run
Serve this folder from an HTTPS host. Do not open `index.html` with `file://` if you want GPS/service-worker functionality.
